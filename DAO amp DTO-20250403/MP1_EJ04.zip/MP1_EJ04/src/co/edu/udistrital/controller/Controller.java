package co.edu.udistrital.controller;

import co.edu.udistrital.model.Mascota;
import co.edu.udistrital.model.Veterinaria;
import co.edu.udistrital.model.persistence.MapHandler;
import co.edu.udistrital.model.persistence.MascotaDTO;
import co.edu.udistrital.model.persistence.VeterinariaDAO;
import co.edu.udistrital.view.VistaConsola;


public class Controller {

	private VistaConsola vista;
	private Veterinaria datos;
	
	public Controller() {
		vista = new VistaConsola();
	}
	
	public void run() {
		datos = new Veterinaria();
		
		funcionalidadAdicionar();
		
		funcionalidadAdicionar();
		
		funcionalidadVerTodos();
		
		
		/*
		if(veteDAO.update(new Mascota("Jully", 30, "Culebra"), new Mascota ("Jully", 30, "Rata"))) {
			vista.mostrarInformacion("Permitio modificar a JULLY");
		}else {
			vista.mostrarInformacion("NO dejo modificar a JULLY");
		}
		
		vista.mostrarInformacion(veteDAO.getAll());
		
		if(veteDAO.delete(new Mascota("Luis", 26, "Perro"))) {
			vista.mostrarInformacion("Permitio eliminar a LUIS");
		}else {
			vista.mostrarInformacion("NO dejo eliminar a LUIS");
		}
		
		vista.mostrarInformacion(veteDAO.getAll());*/
	}
	
	public void funcionalidadAdicionar() {
		String n = vista.leerCadenaTexto("Ingrese nombre de la mascota: ");
		int e = vista.leerDatoEntero("Ingrese edad de la mascota: ");
		String t = vista.leerCadenaTexto("Ingrese tipo de la mascota: ");
		Mascota x = new Mascota(n, e, t);
		MascotaDTO d = MapHandler.convertirMascotaaMascotaDTO(x);
		if(datos.adicionarMascota(d)) {
			vista.mostrarInformacion("Permitio insertar a " + x.getNombre());
		}else {
			vista.mostrarInformacion("NO dejo insertar a " + x.getNombre());
		}
	}
	
	public void funcionalidadVerTodos() {
		String rta = datos.verTodasLasMascotas();	
		if(rta != "") {
			vista.mostrarInformacion("Los datos de las mascotas son: \n" + rta);
		}else {
			vista.mostrarInformacion("NO hay información");
		}
	}
	
	
	
}
