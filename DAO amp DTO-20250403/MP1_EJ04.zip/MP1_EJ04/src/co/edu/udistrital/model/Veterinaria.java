package co.edu.udistrital.model;

import co.edu.udistrital.model.persistence.MapHandler;
import co.edu.udistrital.model.persistence.MascotaDTO;
import co.edu.udistrital.model.persistence.VeterinariaDAO;

public class Veterinaria {

	private VeterinariaDAO vDAO;
	
	public Veterinaria() {
		vDAO = new VeterinariaDAO();
	}

	public VeterinariaDAO getvDAO() {
		return vDAO;
	}

	public void setvDAO(VeterinariaDAO vDAO) {
		this.vDAO = vDAO;
	}
	
	public boolean adicionarMascota(MascotaDTO d) {
		Mascota m = MapHandler.convertirMascotaDTOaMascota(d);
		return vDAO.add(m);
	}
	
	public String verTodasLasMascotas() {
		return vDAO.getAll();
	}
}
