package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.BotonMac;
import co.edu.udistrital.model.VentanaMac;
import co.edu.udistrital.model.fabricaAbstracta.Boton;
import co.edu.udistrital.model.fabricaAbstracta.FabricaDeWidgets;
import co.edu.udistrital.model.fabricaAbstracta.Ventana;

public class MacFabrica implements FabricaDeWidgets {

	@Override
	public Ventana crearVentana() {
		return new VentanaMac();
	}

	@Override
	public Boton crearBoton() {
		return new BotonMac();
	}
	

}
