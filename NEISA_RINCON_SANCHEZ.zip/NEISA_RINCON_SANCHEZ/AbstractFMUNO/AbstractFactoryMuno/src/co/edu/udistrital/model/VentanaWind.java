package co.edu.udistrital.model;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.JFrame;

import co.edu.udistrital.model.fabricaAbstracta.Ventana;

public class VentanaWind implements Ventana{
	JFrame jframe;
	
	public VentanaWind() {
		jframe = new JFrame ("Ventana windows");
		jframe.setLayout(new FlowLayout());
		jframe.getContentPane().setBackground(Color.RED);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

	@Override
	public void caracteristicas(int ancho,int alto) {
		jframe.setSize( ancho,alto);
		
	}

	@Override
	public void resultado() {
		jframe.setVisible(true);
		
	}

	@Override
	public void anadirComponente(Component comp) {
		jframe.add(comp);
		jframe.revalidate();
		jframe.repaint();
		
	}

}
