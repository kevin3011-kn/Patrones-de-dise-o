package co.edu.udistrital.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class VistaPrincipal extends JFrame{
	
	
	private PanelControles pc;
	
	 public VistaPrincipal() {
		 
		 	setTitle("Construccion de interfaces");
			setSize(400, 600);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(253, 119, 253));
			getContentPane().setLayout(null);
			 //setIconImage(new ImageIcon(getClass().getResource("/imagenes/iconoproyecto.png")).getImage());
			
			inicializarComponentes();
			
			setResizable(true);
			setLocationRelativeTo(null);	
			setVisible(true);
	    }
	 
	private void inicializarComponentes() {
		
		
          pc = new PanelControles();
          pc.setBounds(0,0,400,600);
          getContentPane().add(pc);
	     
	     	
		
	}


	public PanelControles getPc() {
		return pc;
	}

	public void setPc(PanelControles pc) {
		this.pc = pc;
	}
	
	

	

}
