package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.BotonLinux;
import co.edu.udistrital.model.VentanaLinux;
import co.edu.udistrital.model.fabricaAbstracta.Boton;
import co.edu.udistrital.model.fabricaAbstracta.FabricaDeWidgets;
import co.edu.udistrital.model.fabricaAbstracta.Ventana;

public class LinuxFabrica implements FabricaDeWidgets {

	@Override
	public Ventana crearVentana() {
		return new VentanaLinux(); //Crea una ventana de tipo linux
	}

	@Override
	public Boton crearBoton() {
		return new BotonLinux(); //Crea un boton  de tipo linux
	}

}
