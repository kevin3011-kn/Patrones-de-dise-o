package co.edu.udistrital.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import co.edu.udistrital.model.fabricaAbstracta.Boton;
import co.edu.udistrital.model.fabricaAbstracta.FabricaDeWidgets;
import co.edu.udistrital.model.fabricaAbstracta.Ventana;
import co.edu.udistrital.model.fabricaConcreta.LinuxFabrica;
import co.edu.udistrital.model.fabricaConcreta.MacFabrica;
import co.edu.udistrital.model.fabricaConcreta.WindowsFabrica;
import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.view.VistaPrincipal;

public class Controller implements ActionListener {
	
	private VistaPrincipal vista;
	private Ventana ventanaActual;
	private FabricaDeWidgets fabrica;
	
	public Controller() {
		
		vista = new VistaPrincipal();
		asignarOyentes();
		
	}
	
public void asignarOyentes() {
    	
    	vista.getPc().getCrearVentanaBtn().addActionListener(this);
    	vista.getPc().getAgregarBotonBtn().addActionListener(this);
        
        
}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		String comando = e.getActionCommand();
		
		 if(comando.equals("AGREGAR")) {
			 
			
			 
			 if (ventanaActual == null) {
		            JOptionPane.showMessageDialog(null, "Primero cree una ventana.");
		            return;
		        }

		        int ancho = Integer.parseInt(vista.getPc().getAnchoBotonField().getText());
		        int alto = Integer.parseInt(vista.getPc().getAltoBotonField().getText());
		        String nombre = vista.getPc().getNombreBotonField().getText();

		        Boton boton = fabrica.crearBoton();
		        boton.caracteristicas(ancho, alto, nombre);
		        ventanaActual.anadirComponente(boton.getComponent());
		        ventanaActual.resultado(); // refresca la vista si es externa
		        
				
			
		}
		 
		 if(comando.equals("CREAR")) {
			
			 
			 String tipo = (String) vista.getPc().getTipoVentanaBox().getSelectedItem();
		        switch (tipo) {
		            case "Windows": fabrica = new WindowsFabrica(); break;
		            case "Mac": fabrica = new MacFabrica(); break;
		            case "Linux": fabrica = new LinuxFabrica(); break;
		        }

		        int ancho = Integer.parseInt(vista.getPc().getAnchoVentanaField().getText());
		        int alto = Integer.parseInt(vista.getPc().getAltoVentanaField().getText());

		        ventanaActual = fabrica.crearVentana();
		        ventanaActual.caracteristicas(ancho, alto);

				
				
		 }
	}


}
