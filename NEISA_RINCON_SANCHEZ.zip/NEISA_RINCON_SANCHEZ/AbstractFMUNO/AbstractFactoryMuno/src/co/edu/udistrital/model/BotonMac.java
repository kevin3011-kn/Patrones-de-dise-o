package co.edu.udistrital.model;

import java.awt.Component;

import javax.swing.JButton;

import co.edu.udistrital.model.fabricaAbstracta.Boton;

public class BotonMac implements Boton{
	JButton jbutton;
	
	public BotonMac(){
		jbutton = new JButton();
	}

	@Override
	public void caracteristicas(int ancho,int alto,String nombre) {
		jbutton.setSize( ancho,alto);
		jbutton.setText(nombre);
		
	}


	@Override
	public Component getComponent() {
		return jbutton;
	}

}
