package co.edu.udistrital.model.fabricaAbstracta;
import java.awt.Component;

public interface Ventana {
	//Metodo que configura las dimensiones de las ventanas
	void caracteristicas(int ancho,int alto);
	
	//Método que permite añadir el boton al JFrame
	void anadirComponente(Component comp);
	
	//Método que permite visualizar la ventana
	void resultado();
	
	

}
