package co.edu.udistrital.model.fabricaAbstracta;

import java.awt.Component;


public interface Boton {
	//Aqui se crean las caracteristicas del boton que el user podra modificar
	void caracteristicas( int ancho,int alto,String nombre);
	
	//Este metodo permite tratar el JButton como componente para que Swing lo pueda usar correctamente 
	public Component getComponent();
	
	

}
