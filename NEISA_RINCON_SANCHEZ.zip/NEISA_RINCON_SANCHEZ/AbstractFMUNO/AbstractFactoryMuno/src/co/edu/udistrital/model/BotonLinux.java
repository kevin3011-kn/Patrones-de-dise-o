package co.edu.udistrital.model;



import java.awt.Component;

import javax.swing.JButton;

import co.edu.udistrital.model.fabricaAbstracta.Boton;

public class BotonLinux implements Boton {
	// Se declara la variabe que almacenara  objetos de tipo JButton 
	JButton jbutton;
	
	public BotonLinux(){
		//Aqui se crea el JButton de tipo linux
		jbutton = new JButton();
	}
	@Override
	public void caracteristicas(int ancho,int alto,String nombre) {
		//Aqui se asigna el tamaño según los datos que ingrese el user
		jbutton.setSize(ancho,alto);
		//Aqui se asigna el nombre según los datos que ingrese el user
		jbutton.setText(nombre);
		
		
	}

	@Override
	// jbutton se convierte a Component para poder insertarse utilizando swing 
	public Component getComponent() {
		return jbutton;
	}

}
