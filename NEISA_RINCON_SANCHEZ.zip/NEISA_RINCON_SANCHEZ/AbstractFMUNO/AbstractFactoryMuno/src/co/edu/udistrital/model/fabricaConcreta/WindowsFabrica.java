package co.edu.udistrital.model.fabricaConcreta;

import co.edu.udistrital.model.BotonWind;
import co.edu.udistrital.model.VentanaWind;
import co.edu.udistrital.model.fabricaAbstracta.Boton;
import co.edu.udistrital.model.fabricaAbstracta.FabricaDeWidgets;
import co.edu.udistrital.model.fabricaAbstracta.Ventana;

public class WindowsFabrica implements FabricaDeWidgets{

	@Override
	public Ventana crearVentana() {
		return new VentanaWind();
	}

	@Override
	public Boton crearBoton() {
		return new BotonWind();
	}

}
