package co.edu.udistrital.model;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;

import javax.swing.JFrame;

import co.edu.udistrital.model.fabricaAbstracta.Ventana;

public class VentanaMac implements Ventana{
	JFrame jframe;
	
	public VentanaMac(){
		jframe = new JFrame ("Ventana mac");
		jframe.setLayout(new FlowLayout());
		jframe.getContentPane().setBackground(Color.BLUE);
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
	
	public void caracteristicas(int ancho,int alto) {
		jframe.setSize( ancho,alto);
	}
	
	public void resultado() {
		jframe.setVisible(true);
	}

	@Override
	public void anadirComponente(Component comp) {
		jframe.add(comp);
		jframe.revalidate();
		jframe.repaint();
		
	}

	

}
