package co.edu.udistrital.view;

import javax.swing.*;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.*;

import co.edu.udistrital.model.fabricaAbstracta.*;
import co.edu.udistrital.model.fabricaConcreta.*;

public class PanelControles extends JPanel {

    private JComboBox<String> tipoVentanaBox;
    private JTextField anchoVentanaField, altoVentanaField;
    private JTextField anchoBotonField, altoBotonField, nombreBotonField;
    private JButton crearVentanaBtn, agregarBotonBtn;

    private Ventana ventanaActual;
    private FabricaDeWidgets fabrica;
    
    public PanelControles() {
		
		setLayout(null);
		setBackground(Color.WHITE);
		setBorder(new TitledBorder("Modulo Principal"));
		inicializarComponentes();
		setVisible(true);
	}


   
 private void inicializarComponentes() {
    	


        tipoVentanaBox = new JComboBox<>(new String[]{"Windows", "Mac", "Linux"});
        tipoVentanaBox.setBounds(120, 30, 150, 25);
        add(tipoVentanaBox);

     
        JLabel tipoVentanaLabel = new JLabel("Tipo de ventana:");
        tipoVentanaLabel.setBounds(10, 30, 100, 25);
        add(tipoVentanaLabel);
        
        anchoVentanaField = new JTextField("600");
        anchoVentanaField.setBounds(170, 70,100, 25);
        add(anchoVentanaField);
        
        JLabel anchoVentanaLabel = new JLabel("Ancho de ventana:");
        anchoVentanaLabel.setBounds(10, 70, 150, 25);
        add(anchoVentanaLabel);
        
        altoVentanaField = new JTextField("400");
        altoVentanaField.setBounds(170, 140,100, 25);
        add(altoVentanaField);
        
        JLabel altoVentanaLabel = new JLabel("Alto de ventana:");
        altoVentanaLabel.setBounds(10, 140, 150, 25);
        add(altoVentanaLabel);
        

        anchoBotonField = new JTextField("100");
        anchoBotonField.setBounds(170, 210,100, 25);
        add(anchoBotonField);
        
        JLabel anchoBotonLabel = new JLabel("Ancho de Boton:");
        anchoBotonLabel.setBounds(10,210, 150, 25);
        add(anchoBotonLabel);
        
        altoBotonField = new JTextField("40");
        altoBotonField.setBounds(170, 280,100, 25);
        add(altoBotonField);
        
        JLabel altoBotonLabel = new JLabel("alto de Boton:");
        altoBotonLabel.setBounds(10, 280, 150, 25);
        add(altoBotonLabel);
        
        nombreBotonField = new JTextField("Botón");
        nombreBotonField.setBounds(170, 350,100, 25);
        add(nombreBotonField);
        
        JLabel nombreBotonLabel = new JLabel("Nombre del boton:");
        nombreBotonLabel.setBounds(10, 350, 150, 25);
        add(nombreBotonLabel);
        
        crearVentanaBtn = new JButton("Crear Ventana");
        crearVentanaBtn.setBounds(90, 420, 150, 30);
        crearVentanaBtn.setForeground(Color.black);
        crearVentanaBtn.setBackground(Color.red);
        crearVentanaBtn.setBorder(null);
        crearVentanaBtn.setActionCommand("CREAR");
		add(crearVentanaBtn);
        
        agregarBotonBtn = new JButton("Agregar Botón");
        agregarBotonBtn.setBounds(90, 470, 150, 30);
        agregarBotonBtn.setForeground(Color.black);
        agregarBotonBtn.setBackground(Color.red);
        agregarBotonBtn.setBorder(null);
        agregarBotonBtn.setActionCommand("AGREGAR");
		add(agregarBotonBtn);
        
        

    

       

       
    }



public JComboBox<String> getTipoVentanaBox() {
	return tipoVentanaBox;
}



public void setTipoVentanaBox(JComboBox<String> tipoVentanaBox) {
	this.tipoVentanaBox = tipoVentanaBox;
}



public JTextField getAnchoVentanaField() {
	return anchoVentanaField;
}



public void setAnchoVentanaField(JTextField anchoVentanaField) {
	this.anchoVentanaField = anchoVentanaField;
}



public JTextField getAltoVentanaField() {
	return altoVentanaField;
}



public void setAltoVentanaField(JTextField altoVentanaField) {
	this.altoVentanaField = altoVentanaField;
}



public JTextField getAnchoBotonField() {
	return anchoBotonField;
}



public void setAnchoBotonField(JTextField anchoBotonField) {
	this.anchoBotonField = anchoBotonField;
}



public JTextField getAltoBotonField() {
	return altoBotonField;
}



public void setAltoBotonField(JTextField altoBotonField) {
	this.altoBotonField = altoBotonField;
}



public JTextField getNombreBotonField() {
	return nombreBotonField;
}



public void setNombreBotonField(JTextField nombreBotonField) {
	this.nombreBotonField = nombreBotonField;
}



public JButton getCrearVentanaBtn() {
	return crearVentanaBtn;
}



public void setCrearVentanaBtn(JButton crearVentanaBtn) {
	this.crearVentanaBtn = crearVentanaBtn;
}



public JButton getAgregarBotonBtn() {
	return agregarBotonBtn;
}



public void setAgregarBotonBtn(JButton agregarBotonBtn) {
	this.agregarBotonBtn = agregarBotonBtn;
}



public Ventana getVentanaActual() {
	return ventanaActual;
}



public void setVentanaActual(Ventana ventanaActual) {
	this.ventanaActual = ventanaActual;
}



public FabricaDeWidgets getFabrica() {
	return fabrica;
}



public void setFabrica(FabricaDeWidgets fabrica) {
	this.fabrica = fabrica;
}
 

  
 
 
}


