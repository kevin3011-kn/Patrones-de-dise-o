package co.edu.udistrital.model.fabricaAbstracta;

public interface FabricaDeWidgets {
	
	//Metodo que devuelve un objeto de tipo ventana
	 Ventana crearVentana();
	//Metodo que devuelve un objeto de tipo boton
	 Boton crearBoton();
	

}
