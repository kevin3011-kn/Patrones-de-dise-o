package co.edu.udistrital.model;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import javax.swing.JFrame;

import co.edu.udistrital.model.fabricaAbstracta.Ventana;

public class VentanaLinux implements Ventana{
	
	//Declara una variable de tipo JFrame
	JFrame jframe;
	
	public VentanaLinux() {
		//Se crea la ventana
		jframe = new JFrame ("Ventana linux");
		// Permite que los componente se ordenen en fila
		jframe.setLayout(new FlowLayout());
		//El color de la ventana es predefinido 
		jframe.getContentPane().setBackground(Color.PINK);
		//Cierra la aplicación una vez se cierre la ventana 
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

	//Permite establecer el tamaño de la ventana utilizando dos pararmetros
	@Override
	public void caracteristicas( int ancho,int alto) {
		jframe.setSize(ancho,alto);
		
	}
	
	@Override
	public void anadirComponente(Component comp) {
		jframe.add(comp); //Añade el boton
		jframe.revalidate(); // Organiza los componentes
		jframe.repaint(); // Dibuja nuevamente la ventana
		
	}

	@Override
	public void resultado() {
		jframe.setVisible(true); //Muestra la ventana
		
	}
}
