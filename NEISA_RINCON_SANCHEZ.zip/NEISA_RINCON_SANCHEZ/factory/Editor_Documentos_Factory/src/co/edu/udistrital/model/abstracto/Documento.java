package co.edu.udistrital.model.abstracto;

// Clase abstracta Documento que actúa como base para diferentes tipos de documentos
public abstract class Documento {
	
	protected String contenido; // Contenido común para todos los documentos
	protected String tipo;
	
	// Constructor que recibe el contenido del documento
	public Documento(String tipo,String contenido) {
       
        this.tipo = tipo;
        this.contenido = contenido;
    }
	
	 // Método abstracto que cada subclase debe implementar
	 public abstract String mostrarInfo();

	// Getter para obtener el contenido
	 public String getContenido() {
	        return contenido;
	 }
	 
	// Método que permite modificar el contenido
	    public void setContenido(String nuevoContenido) {
	        this.contenido = nuevoContenido;
	    }

}
