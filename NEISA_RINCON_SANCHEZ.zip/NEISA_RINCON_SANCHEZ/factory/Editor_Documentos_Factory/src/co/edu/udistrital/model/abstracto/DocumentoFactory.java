package co.edu.udistrital.model.abstracto;

//Interfaz DocumentoFactory que define el método para crear documentos
public  interface  DocumentoFactory {
	
	// Método para crear documentos según el tipo
	 Documento crearDocumento(String tipo, String contenido);

}
