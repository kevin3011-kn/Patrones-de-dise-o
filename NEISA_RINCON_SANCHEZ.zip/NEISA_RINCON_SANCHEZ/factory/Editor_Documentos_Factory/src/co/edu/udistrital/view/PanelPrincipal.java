package co.edu.udistrital.view;

import javax.swing.*;
import javax.swing.border.TitledBorder;

import java.awt.*;

public class PanelPrincipal extends JPanel {

   
    
    private JButton guardar;
    private JButton mostrar;
    private JButton borrar;
    private JButton salir;
    
    private JComboBox<String> tipoTexto;
    
    private JTextArea salidaArea;
    private JTextArea MostrarArea;
    
    
    
    public PanelPrincipal() {
    	
    	setLayout(null);
		setBackground(Color.lightGray);
		setBorder(new TitledBorder("Modulo Principal"));
		inicializarComponentes();
		setVisible(true);
    	
    	
    }
   
    public void inicializarComponentes() {
    	
        
    	tipoTexto = new JComboBox<>(new String[]{"Texto Plano", "PDF"});
    	tipoTexto.setBounds(30, 30, 100, 30);
    	tipoTexto.setActionCommand("ACTUALIZAR");
         add(tipoTexto); 
       
         guardar = new JButton("Guardar");
         guardar.setBounds(150, 30,80, 30);
         guardar.setForeground(Color.black);
         guardar.setBackground(Color.red);
         guardar.setBorder(null);
         guardar.setActionCommand("guardar");
		add(guardar);
		
		mostrar = new JButton("mostrar");
		mostrar.setBounds(250, 30, 80, 30);
		mostrar.setForeground(Color.black);
		mostrar.setBackground(Color.red);
		mostrar.setBorder(null);
		mostrar.setActionCommand("mostrar");
		add(mostrar);
		
		borrar = new JButton("borrar");
		borrar.setBounds(340, 30, 80, 30);
		borrar.setForeground(Color.black);
		borrar.setBackground(Color.red);
		borrar.setBorder(null);
		borrar.setActionCommand("borrar");
		add(borrar);
		
		salir = new JButton("salir");
		salir.setBounds(440, 30, 80, 30);
		salir.setForeground(Color.black);
		salir.setBackground(Color.red);
		salir.setBorder(null);
		salir.setActionCommand("salir");
		add(salir);
		
		salidaArea = new JTextArea();
		salidaArea.setBounds(10, 80, 580, 180);
		salidaArea.setEditable(true);
		salidaArea.setForeground(Color.gray);
		add(salidaArea);
		
		MostrarArea = new JTextArea();
		MostrarArea.setBounds(10, 270, 580, 180);
		MostrarArea.setEditable(false);
		MostrarArea.setForeground(Color.gray);
		add(MostrarArea);
		
		
    	
    
        
    }
    
    public void mostrarSalida(String mensaje) {
        MostrarArea.setText(mensaje);
    }

	public JButton getGuardar() {
		return guardar;
	}

	public void setGuardar(JButton guardar) {
		this.guardar = guardar;
	}

	public JButton getMostrar() {
		return mostrar;
	}

	public void setMostrar(JButton mostrar) {
		this.mostrar = mostrar;
	}

	public JButton getBorrar() {
		return borrar;
	}

	public void setBorrar(JButton borrar) {
		this.borrar = borrar;
	}

	public JButton getSalir() {
		return salir;
	}

	public void setSalir(JButton salir) {
		this.salir = salir;
	}

	public JComboBox<String> getTipoTexto() {
		return tipoTexto;
	}

	public void setTipoTexto(JComboBox<String> tipoTexto) {
		this.tipoTexto = tipoTexto;
	}

	public JTextArea getSalidaArea() {
		return salidaArea;
	}

	public void setSalidaArea(JTextArea salidaArea) {
		this.salidaArea = salidaArea;
	}

	public JTextArea getMostrarArea() {
		return MostrarArea;
	}

	public void setMostrarArea(JTextArea mostrarArea) {
		MostrarArea = mostrarArea;
	}


	
    
    
}

