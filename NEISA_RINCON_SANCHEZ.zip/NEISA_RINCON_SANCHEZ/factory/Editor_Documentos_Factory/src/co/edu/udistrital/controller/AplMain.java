package co.edu.udistrital.controller;


//Clase principal que inicia la applicacion del editor de documentos
public class AplMain {

	public static void main(String[] args) {

		EditorController control;
		control = new EditorController();


	}

}
