package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Documento;

//Clase PDF que extiende Documento y representa un documento tipo PDF.
public class PDF extends Documento{

	// Constructor que llama al constructor de la superclase
	public PDF(String tipo,String contenido) {
		super(tipo,contenido);
		
	}
	
	// Implementación del método mostrar para PDF
	@Override
	public String mostrarInfo() {

        return tipo+ "---" + contenido ;		

		
	}

   
}
