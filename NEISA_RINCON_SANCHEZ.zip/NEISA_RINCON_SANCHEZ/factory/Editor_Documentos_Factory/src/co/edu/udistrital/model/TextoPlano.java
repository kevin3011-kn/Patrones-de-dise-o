package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Documento;

//Clase TextoPlano que extiende Documento y representa un documento de texto simple.
public class TextoPlano extends Documento{
	
    // Constructor que llama al constructor de la superclase
	public TextoPlano(String tipo,String contenido) {
		super(tipo,contenido);
		
	}
	
	// Implementación del método mostrar para texto plano
	@Override
	public String mostrarInfo() {
		return tipo + " --- " + contenido ;
	}

}
