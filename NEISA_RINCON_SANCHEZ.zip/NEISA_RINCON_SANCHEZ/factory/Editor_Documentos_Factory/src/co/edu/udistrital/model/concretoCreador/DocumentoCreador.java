package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.PDF;
import co.edu.udistrital.model.TextoPlano;
import co.edu.udistrital.model.abstracto.Documento;
import co.edu.udistrital.model.abstracto.DocumentoFactory;

//Clase DocumentoCreador que implementa DocumentoFactory y se encarga de crear instancias de documentos.
public  class DocumentoCreador implements DocumentoFactory{

    // Método que recibe el tipo de documento y su contenido, y retorna la instancia correspondiente
	@Override
	public Documento crearDocumento(String tipo, String contenido) {
		switch (tipo.trim().toLowerCase()) {
        case "texto":
            return new TextoPlano(tipo,contenido);
        case "pdf":
            return new PDF(tipo,contenido);
        default:
            throw new IllegalArgumentException("Tipo de documento no válido: " + tipo);
	     }
	
    }
}
