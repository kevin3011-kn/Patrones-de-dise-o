package co.edu.udistrital.controller;


import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import co.edu.udistrital.model.PDF;
import co.edu.udistrital.model.TextoPlano;
import co.edu.udistrital.model.abstracto.Documento;
import co.edu.udistrital.model.abstracto.DocumentoFactory;
import co.edu.udistrital.model.concretoCreador.DocumentoCreador;
import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.view.VistaPrincipal;


//Clase Editor que actúa como controlador principal del sistema.
public class EditorController implements ActionListener{

	private VistaPrincipal vista1;
	private VistaConsola vista;  // Referencia a la vista (consola)
	private DocumentoFactory creador; // Fábrica de documentos
    private List<Documento> documentosBase;

    // Constructor que inicializa la vista y la fábrica de documentos
    public EditorController() {
    	
    	vista1 = new VistaPrincipal();
    	//this.vista = new VistaConsola();
    
    	this.documentosBase = new ArrayList<Documento>();
        inicializarDocumentosBase();
        asignarOyentes();
	}
    
   private void inicializarDocumentosBase() {
	   
	   documentosBase.add(new TextoPlano("Texto - ","Documento de texto inicial \n"));
	   documentosBase.add(new PDF("pdf - ","Documento PDF inicial\n"));
       
	}

   public void asignarOyentes() {
   	
   	vista1.getPp().getGuardar().addActionListener(this);
	vista1.getPp().getMostrar().addActionListener(this);
	vista1.getPp().getBorrar().addActionListener(this);
	vista1.getPp().getSalir().addActionListener(this);

   	
   }
   

   public void actionPerformed(ActionEvent e) {
   	
   	String comando = e.getActionCommand();
   	
   	 if(comando.equals("guardar")) {
   		 
   		
        
   		 guardarDocumento();

     
   			 
   		 }
   	 if(comando.equals("mostrar")) {
   		 
   		mostrarDocumentos();
   	   
   		 
   		 
		 }
   	 if(comando.equals("borrar")) {
   		 
   		borrarDocumentos();
   		 
		 }
   	 if(comando.equals("salir")) {
   		 
   		 System.exit(0);
   		 
		 }
   
   }
   
   private void guardarDocumento() {
	    String contenido = vista1.getPp().getSalidaArea().getText().trim();

	    if (contenido.isEmpty()) {
	        JOptionPane.showMessageDialog(vista1, "El contenido está vacío", "Error", JOptionPane.ERROR_MESSAGE);
	        return;
	    }

	    String tipoSeleccionado = (String) vista1.getPp().getTipoTexto().getSelectedItem();
	    String tipoDoc = tipoSeleccionado.equalsIgnoreCase("Texto Plano") ? "texto" : "pdf";

	    if (creador == null) {
	        creador = new DocumentoCreador(); 
	    }

	    Documento docNuevo = creador.crearDocumento(tipoDoc, contenido);
	    documentosBase.add(docNuevo);

	    JOptionPane.showMessageDialog(vista1, "Documento guardado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
	    vista1.getPp().getSalidaArea().setText(""); 
	}
   
   
   private void mostrarDocumentos() {
	    if (documentosBase.isEmpty()) {
	        vista1.getPp().mostrarSalida("No hay documentos para mostrar.");
	        return;
	    }

	    StringBuilder builder = new StringBuilder();
	    for (Documento doc : documentosBase) {
	        builder.append(doc.mostrarInfo()).append("\n--------------------------\n");
	    }

	    vista1.getPp().mostrarSalida(builder.toString());
	}
   
   private void borrarDocumentos() {
	    documentosBase.clear();
	    vista1.getPp().mostrarSalida(""); 
	    JOptionPane.showMessageDialog(vista1, "Todos los documentos han sido borrados.", "Información", JOptionPane.INFORMATION_MESSAGE);
	}
   
   
   
   
   
   
   
   
   
   

	
    
}
