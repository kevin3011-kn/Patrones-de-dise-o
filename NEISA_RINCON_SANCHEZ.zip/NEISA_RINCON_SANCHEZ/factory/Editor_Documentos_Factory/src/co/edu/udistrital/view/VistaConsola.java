package co.edu.udistrital.view;

import java.util.Scanner;

//Clase VistaConsola que se encarga de mostrar el menú y recibir entradas del usuario.
public class VistaConsola {
	
	// Scanner para leer entrada del usuario
	private Scanner sc;
	
	public VistaConsola() {
		sc = new Scanner(System.in);
	}
	
    // Muestra el menú principal en consola
	 public void mostrarMenu() {
	        System.out.println("\n ---- MENÚ DEL EDITOR -----");
	        System.out.println("1. Ver documentos base");
	        System.out.println("2. Editar documento existente");
	        System.out.println("3. Crear documento de texto");
	        System.out.println("4. Crear documento PDF");
	        System.out.println("5. Salir");
	        System.out.print("Seleccione una opción: ");
	    }

	 // Lee la opción ingresada por el usuario
	 public int leerOpcion() {
	        try {
	            return Integer.parseInt(sc.nextLine());
	        } catch (NumberFormatException e) {
	            return -1;// Devuelve -1 si la entrada no es un número válido
	        }
	 }
	 
	// Pide al usuario que ingrese el contenido del documento
	    public String pedirContenido() {
	        System.out.println("Ingrese el contenido del documento:");
	        return sc.nextLine();
	    }
     //Pide un texto
	 public String leerDatoTexto(String mensaje) {
	        System.out.print(mensaje);
	        return sc.nextLine();
	 }
	 
	 //Muestra unnmensaje en consola
	 public void mostrarInformacion(String mensaje) {
			System.out.println(mensaje);
     }

}