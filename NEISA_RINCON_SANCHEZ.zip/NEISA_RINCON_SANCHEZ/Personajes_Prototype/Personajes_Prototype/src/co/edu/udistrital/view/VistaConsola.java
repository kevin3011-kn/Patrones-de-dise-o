package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {
	
	private Scanner sc;
	
	public VistaConsola() {
		sc = new Scanner(System.in);
	}
	
	// Método para mostrar información
	public void mostrarInformacion(String mensaje) {
		System.out.println(mensaje);
	}
	
	// Método para leer texto desde consola
    public String leerDatoTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }
    
 // Método para leer enteros desde consola
    public int leerDatoEntero(String mensaje) {
        int dato = 0;
        System.out.print(mensaje);
        while (!sc.hasNextInt()) {
            System.out.print("Ingrese un número válido: ");
            sc.next(); // descarta la entrada inválida
        }
        dato = sc.nextInt();
        sc.nextLine(); // limpia el salto de línea pendiente
        return dato;
    }

	

}
