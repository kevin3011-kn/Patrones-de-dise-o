package co.edu.udistrital.model;

public class Personaje implements Cloneable{ 
	// La clase Personaje implementa Cloneable para permitir clonar objetos

	//Atributos
	private String nombre;
	private int puntosDeVida;
	private String Habilidades;
	private int nivel;

	 // Constructor que inicializa todos los atributos del personaje
	public Personaje(String nombre, int puntosDeVida, String Habilidades, int nivel) {
		this.nombre = nombre;
		this.puntosDeVida = puntosDeVida;
		this.Habilidades = Habilidades;
		this.nivel = nivel;
	}
	
    // Método sobrescrito clone() que permite clonar un objeto Personaje
	  @Override
	    public Personaje clone() {
		  try {
			   // Se usa super.clone() para realizar una copia superficial del objeto
	            return (Personaje) super.clone();
	        } catch (CloneNotSupportedException e) {
	            throw new RuntimeException("No se pudo clonar el personaje", e);
	        }
	  }
	  
	 
	// Método toString sobrescrito para representar al personaje en formato de texto
	@Override
	public String toString() {
		return  "Nombre: " + nombre +
	               "\nPuntos de Vida: " + puntosDeVida +
	               "\nHabilidades: " + Habilidades +
	               "\nNivel: " + nivel;
	}

		// Setters para personalizar el clon
	    public void setNombre(String nombre) {
	        this.nombre = nombre;
	    }

	    public void setPuntosDeVida(int puntosDeVida) {
	        this.puntosDeVida = puntosDeVida;
	    }

	    public void setHabilidades(String Habilidades) {
	        this.Habilidades = Habilidades;
	    }

	    public void setNivel(int nivel) {
	        this.nivel = nivel;
	    }

		public String getNombre() {
			return nombre;
		}

		public int getPuntosDeVida() {
			return puntosDeVida;
		}

		public String getHabilidades() {
			return Habilidades;
		}

		public int getNivel() {
			return nivel;
		}
	    
	    

}
