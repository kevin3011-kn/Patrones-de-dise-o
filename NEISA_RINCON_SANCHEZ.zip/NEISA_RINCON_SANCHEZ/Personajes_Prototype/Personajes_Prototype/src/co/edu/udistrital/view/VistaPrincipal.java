package co.edu.udistrital.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class VistaPrincipal extends JFrame{
	
	
	private VistaGrafica vg;
	
	 public VistaPrincipal() {
		 
		 	setTitle("Personajes");
			setSize(800, 600);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			getContentPane().setBackground(new Color(253, 119, 253));
			getContentPane().setLayout(null);
			
			
			inicializarComponentes();
			
			setResizable(true);
			setLocationRelativeTo(null);	
			setVisible(true);
	    }
	 
	private void inicializarComponentes() {
		
		
		 vg = new VistaGrafica();
		 vg.setBounds(0,0,800,600);
         getContentPane().add(vg);
           	
		
	}

	public VistaGrafica getVg() {
		return vg;
	}

	public void setVg(VistaGrafica vg) {
		this.vg = vg;
	}

	

	

	

}
