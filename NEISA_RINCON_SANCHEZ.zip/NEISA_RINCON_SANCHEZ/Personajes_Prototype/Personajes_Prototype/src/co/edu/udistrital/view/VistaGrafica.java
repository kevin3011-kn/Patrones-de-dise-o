package co.edu.udistrital.view;

import javax.swing.*;
import javax.swing.border.TitledBorder;

import java.awt.*;

public class VistaGrafica extends JPanel {

    private JTextField nombreField;
    private JTextField vidaField;
    private JTextField habilidadesField;
    private JTextField nivelField;
    
    private JButton clonarBtn;
    private JButton modificarBtn;
    private JButton mostrarBtn;
    private JButton salirBtn;
    
    private JLabel nombre;
    private JLabel puntosVida;
    private JLabel habilidades;
    private JLabel nivel;
    
    private JTextArea salidaArea;
    
    
    
    public VistaGrafica() {
    	
    	setLayout(null);
		setBackground(Color.WHITE);
		setBorder(new TitledBorder("Modulo Principal"));
		inicializarComponentes();
		setVisible(true);
    	
    	
    }
   
    public void inicializarComponentes() {
    	
        
        nombreField = new JTextField(" ");
        nombreField.setBounds(170, 80,100, 25);
        add(nombreField);
        
        nombre = new JLabel(" Nombre : :");
        nombre.setBounds(10, 80, 150, 25);
        add(nombre);
        
        vidaField = new JTextField(" ");
        vidaField.setBounds(170, 140,100, 25);
        add(vidaField);
        
         puntosVida = new JLabel("Puntos de Vida :");
         puntosVida.setBounds(10, 140, 150, 25);
        add(puntosVida);
        

        habilidadesField = new JTextField(" ");
        habilidadesField.setBounds(170, 210,100, 25);
        add(habilidadesField);
        
        habilidades = new JLabel("habilidades :");
        habilidades.setBounds(10,210, 150, 25);
        add(habilidades);
        
        nivelField = new JTextField(" ");
        nivelField.setBounds(170, 280,100, 25);
        add(nivelField);
        
        nivel = new JLabel("Nivel :");
        nivel.setBounds(10, 280, 150, 25);
        add(nivel);
      

       
        clonarBtn = new JButton("clonar");
        clonarBtn.setBounds(90, 350, 150, 30);
        clonarBtn.setForeground(Color.black);
        clonarBtn.setBackground(Color.red);
        clonarBtn.setBorder(null);
        clonarBtn.setActionCommand("CLONAR");
		add(clonarBtn);
		
		modificarBtn = new JButton("modificar");
		modificarBtn.setBounds(90, 390, 150, 30);
		modificarBtn.setForeground(Color.black);
		modificarBtn.setBackground(Color.red);
		modificarBtn.setBorder(null);
        modificarBtn.setActionCommand("MODIFICAR");
		add(modificarBtn);
		
		mostrarBtn = new JButton("mostrar");
		mostrarBtn.setBounds(90, 430, 150, 30);
		mostrarBtn.setForeground(Color.black);
		mostrarBtn.setBackground(Color.red);
		mostrarBtn.setBorder(null);
		mostrarBtn.setActionCommand("MOSTRAR");
		add(mostrarBtn);
		
		salirBtn = new JButton("salir");
		salirBtn.setBounds(90, 470, 150, 30);
		salirBtn.setForeground(Color.black);
		salirBtn.setBackground(Color.red);
		salirBtn.setBorder(null);
		salirBtn.setActionCommand("SALIR");
		add(salirBtn);
		
		salidaArea = new JTextArea();
		salidaArea.setBounds(300, 80, 300, 450);
		salidaArea.setEditable(false);
		salidaArea.setForeground(Color.gray);
		add(salidaArea);
		
		
    	
    
        
    }
    
    public void mostrarSalida(String mensaje) {
        salidaArea.setText(mensaje);
    }

	public String getNombreField() {
		return nombreField.getText();
	}
	
	  public void setNombreField(String nombre) {
	        nombreField.setText(nombre); 
	    }

	

	public String getVidaField() {
		return vidaField.getText();
	}

	public void setVidaField(String vida) {
		vidaField.setText(vida);
	}

	public String getHabilidadesField() {
		return habilidadesField.getText();
	}

	public void setHabilidadesField(String habilidades) {
		habilidadesField.setText(habilidades);;
	}

	public String getNivelField() {
		return nivelField.getText();
	}

	public void setNivelField(String nivel) {
		nivelField.setText(nivel);
	}

	public JButton getClonarBtn() {
		return clonarBtn;
	}

	public void setClonarBtn(JButton clonarBtn) {
		this.clonarBtn = clonarBtn;
	}

	public JButton getModificarBtn() {
		return modificarBtn;
	}

	public void setModificarBtn(JButton modificarBtn) {
		this.modificarBtn = modificarBtn;
	}

	public JButton getMostrarBtn() {
		return mostrarBtn;
	}

	public void setMostrarBtn(JButton mostrarBtn) {
		this.mostrarBtn = mostrarBtn;
	}

	public JButton getSalirBtn() {
		return salirBtn;
	}

	public void setSalirBtn(JButton salirBtn) {
		this.salirBtn = salirBtn;
	}

	public JLabel getNombre() {
		return nombre;
	}

	public void setNombre(JLabel nombre) {
		this.nombre = nombre;
	}

	public JLabel getPuntosVida() {
		return puntosVida;
	}

	public void setPuntosVida(JLabel puntosVida) {
		this.puntosVida = puntosVida;
	}

	public JLabel getHabilidades() {
		return habilidades;
	}

	public void setHabilidades(JLabel habilidades) {
		this.habilidades = habilidades;
	}

	public JLabel getNivel() {
		return nivel;
	}

	public void setNivel(JLabel nivel) {
		this.nivel = nivel;
	}

	public JTextArea getSalidaArea() {
		return salidaArea;
	}

	public void setSalidaArea(JTextArea salidaArea) {
		this.salidaArea = salidaArea;
	}

	
    
    
}

