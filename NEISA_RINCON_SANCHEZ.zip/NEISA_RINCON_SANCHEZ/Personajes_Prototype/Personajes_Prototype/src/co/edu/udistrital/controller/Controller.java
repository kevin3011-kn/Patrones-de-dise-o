package co.edu.udistrital.controller;

import co.edu.udistrital.model.Personaje;
import co.edu.udistrital.view.VistaGrafica;
import co.edu.udistrital.view.VistaPrincipal;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {

    private VistaPrincipal vista;
    private Personaje personajeBase;
    private Personaje personajeClonado;

    public Controller() {
    	
        vista = new VistaPrincipal();

        // Personaje base inicial
        personajeBase = new Personaje("Guerrero", 100, "Espada, Defensa", 1);

        // Mostrar datos iniciales en la vista
        cargarDatosPersonajeBase();
        
        asignarOyentes();
        
    }
     
    public void asignarOyentes() {
    	
    	vista.getVg().getClonarBtn().addActionListener(this);
    	vista.getVg().getModificarBtn().addActionListener(this);
    	vista.getVg().getMostrarBtn().addActionListener(this);
    	vista.getVg().getSalirBtn().addActionListener(this);

    	
    }
    
    
    
    public void actionPerformed(ActionEvent e) {
    	
    	String comando = e.getActionCommand();
    	
    	 if(comando.equals("CLONAR")) {
    		 
    		 clonarPersonaje();
    		 
    		 }
    	 
    	 if(comando.equals("MODIFICAR")) {
    		 
    		 modificarPersonajeClonado();
    		 
		 }
    	 
    	 if(comando.equals("MOSTRAR")) {
    		 
    		 mostrarPersonajes();
		 }
    	 
    	 if(comando.equals("SALIR")) {
    		 
    		 int confirm = JOptionPane.showConfirmDialog(vista, "¿Está seguro que desea salir?", "Salir", JOptionPane.YES_NO_OPTION);
             if (confirm == JOptionPane.YES_OPTION) {
                 System.exit(0);
             }
    		 
    		 
		 }
    	 
    }
    

    private void cargarDatosPersonajeBase() {
    	
        vista.getVg().setNombreField(personajeBase.getNombre());
        vista.getVg().setVidaField(String.valueOf(personajeBase.getPuntosDeVida()));
        vista.getVg().setHabilidadesField(personajeBase.getHabilidades());
        vista.getVg().setNivelField(String.valueOf(personajeBase.getNivel()));
        vista.getVg().mostrarSalida("--- Personaje Base cargado ---");
    }

    
    private void clonarPersonaje() {

        personajeClonado = personajeBase.clone();
        vista.getVg().mostrarSalida("Personaje clonado exitosamente.");
    }

    private void modificarPersonajeClonado() {
        if (personajeClonado == null) {
        	vista.getVg().mostrarSalida("Debe clonar primero un personaje.");
            return;
        }

        try {
            String nuevoNombre = vista.getVg().getNombreField();
            int nuevaVida = Integer.parseInt(vista.getVg().getVidaField());
            String nuevasHabilidades = vista.getVg().getHabilidadesField();
            int nuevoNivel = Integer.parseInt(vista.getVg().getNivelField());

            personajeClonado.setNombre(nuevoNombre);
            personajeClonado.setPuntosDeVida(nuevaVida);
            personajeClonado.setHabilidades(nuevasHabilidades);
            personajeClonado.setNivel(nuevoNivel);

            vista.getVg().mostrarSalida("Personaje clonado modificado correctamente.");

        } catch (NumberFormatException ex) {
        	vista.getVg().mostrarSalida("Por favor, ingrese números válidos en puntos de vida y nivel.");
        }
    }

    private void mostrarPersonajes() {
        StringBuilder sb = new StringBuilder();

        sb.append("--- PERSONAJE BASE ---\n");
        sb.append(personajeBase.toString()).append("\n\n");

        if (personajeClonado != null) {
            sb.append("--- PERSONAJE CLONADO ---\n");
            sb.append(personajeClonado.toString()).append("\n");
        } else {
            sb.append("(No se ha clonado ningún personaje aún.)\n");
        }

        vista.getVg().mostrarSalida(sb.toString());
    }

   
}
