package co.edu.udistrital.view;

import javax.swing.*;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.awt.event.*;

public class PanelPrincipal extends JPanel {

    private JComboBox<String> tipoComputadoraCombo;
    private JTextField procesadorField, ramField, discoDuroField, tarjetaGraficaField;
    private JTextArea resultadoArea;
    private JButton crearButton,actualizarButton;
    private JLabel tipo,procesador,ram,disco,tarjeta;
    
    public PanelPrincipal() {
    	
    	setLayout(null);
		setBackground(Color.WHITE);
		setBorder(new TitledBorder("Modulo Principal"));
		inicializarComponentes();
		setVisible(true);
	
    }

    public void inicializarComponentes() {
        

    	  

       
        tipoComputadoraCombo = new JComboBox<>(new String[]{"Gaming", "Oficina", "Portátil"});
        tipoComputadoraCombo.setBounds(170, 30, 150, 25);
        tipoComputadoraCombo.setActionCommand("ACTUALIZAR");
        add(tipoComputadoraCombo);
        
        tipo = new JLabel("Tipo de computadora:");
        tipo.setBounds(10, 30, 150, 25);
        add(tipo);
        
        procesadorField = new JTextField(" ");
        procesadorField.setBounds(170, 80,100, 25);
        add(procesadorField);
        
        procesador = new JLabel("Procesador (núcleos):");
        procesador.setBounds(10, 80, 150, 25);
        add(procesador);
        
        ramField = new JTextField(" ");
        ramField.setBounds(170, 140,100, 25);
        add(ramField);
        
         ram = new JLabel("RAM (GB) :");
         ram.setBounds(10, 140, 150, 25);
        add(ram);
        

        discoDuroField = new JTextField(" ");
        discoDuroField.setBounds(170, 210,100, 25);
        add(discoDuroField);
        
        disco = new JLabel("Disco Duro (GB):");
        disco.setBounds(10,210, 150, 25);
        add(disco);
        
        tarjetaGraficaField = new JTextField(" ");
        tarjetaGraficaField.setBounds(170, 280,100, 25);
        add(tarjetaGraficaField);
        
        tarjeta = new JLabel("Tarjeta Gráfica (GB):");
        tarjeta.setBounds(10, 280, 150, 25);
        add(tarjeta);
      

        // Botón crear computadora
        crearButton = new JButton("Crear Computadora");
        crearButton.setBounds(90, 350, 150, 30);
        crearButton.setForeground(Color.black);
        crearButton.setBackground(Color.red);
        crearButton.setBorder(null);
        crearButton.setActionCommand("CREAR");
		add(crearButton);
		
		
		
		resultadoArea = new JTextArea();
		resultadoArea.setBounds(290, 80, 300, 390);
		resultadoArea.setEditable(false);
		resultadoArea.setForeground(Color.gray);
		add(resultadoArea);
		

     

   
    }

    private void actualizarCampos() {
        String tipo = (String) tipoComputadoraCombo.getSelectedItem();

        switch (tipo) {
            case "Gaming":
                procesadorField.setEnabled(true);
                ramField.setEnabled(true);
                discoDuroField.setEnabled(true);
                tarjetaGraficaField.setEnabled(true);
                break;
            case "Oficina":
                procesadorField.setEnabled(true);
                ramField.setEnabled(true);
                discoDuroField.setEnabled(true);
                tarjetaGraficaField.setEnabled(false);
                tarjetaGraficaField.setText("");
                break;
            case "Portátil":
                procesadorField.setEnabled(true);
                ramField.setEnabled(true);
                discoDuroField.setEnabled(false);
                discoDuroField.setText("");
                tarjetaGraficaField.setEnabled(true);
                break;
        }
    }

   

	public JComboBox<String> getTipoComputadoraCombo() {
		return tipoComputadoraCombo;
	}

	public void setTipoComputadoraCombo(JComboBox<String> tipoComputadoraCombo) {
		this.tipoComputadoraCombo = tipoComputadoraCombo;
	}

	public JTextField getProcesadorField() {
		return procesadorField;
	}

	public void setProcesadorField(JTextField procesadorField) {
		this.procesadorField = procesadorField;
	}

	public JTextField getRamField() {
		return ramField;
	}

	public void setRamField(JTextField ramField) {
		this.ramField = ramField;
	}

	public JTextField getDiscoDuroField() {
		return discoDuroField;
	}

	public void setDiscoDuroField(JTextField discoDuroField) {
		this.discoDuroField = discoDuroField;
	}

	public JTextField getTarjetaGraficaField() {
		return tarjetaGraficaField;
	}

	public void setTarjetaGraficaField(JTextField tarjetaGraficaField) {
		this.tarjetaGraficaField = tarjetaGraficaField;
	}

	public JTextArea getResultadoArea() {
		return resultadoArea;
	}

	public void setResultadoArea(JTextArea resultadoArea) {
		this.resultadoArea = resultadoArea;
	}

	public JButton getCrearButton() {
		return crearButton;
	}

	public void setCrearButton(JButton crearButton) {
		this.crearButton = crearButton;
	}

	public JButton getActualizarButton() {
		return actualizarButton;
	}

	public void setActualizarButton(JButton actualizarButton) {
		this.actualizarButton = actualizarButton;
	}

	public JLabel getTipo() {
		return tipo;
	}

	public void setTipo(JLabel tipo) {
		this.tipo = tipo;
	}

	public JLabel getProcesador() {
		return procesador;
	}

	public void setProcesador(JLabel procesador) {
		this.procesador = procesador;
	}

	public JLabel getRam() {
		return ram;
	}

	public void setRam(JLabel ram) {
		this.ram = ram;
	}

	public JLabel getDisco() {
		return disco;
	}

	public void setDisco(JLabel disco) {
		this.disco = disco;
	}

	public JLabel getTarjeta() {
		return tarjeta;
	}

	public void setTarjeta(JLabel tarjeta) {
		this.tarjeta = tarjeta;
	}
    
    
}
