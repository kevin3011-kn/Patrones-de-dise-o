package co.edu.udistrital.model;

public interface Builder {
	
	//Pasos para crear la computadora
	Builder reset();
	Builder setProcesador(int procesador);
	Builder setRam(int ram);
	Builder setDiscoDuro(int discoDuro);
	Builder setTarjetaGrafica(int tarjetaGrafica);
	Builder setColor(String color);
	
	//Retorna Un Computador
	Computadora build();
	

}
