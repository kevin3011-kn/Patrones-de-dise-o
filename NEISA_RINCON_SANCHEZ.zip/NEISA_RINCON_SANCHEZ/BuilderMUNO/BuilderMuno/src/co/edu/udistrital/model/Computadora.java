package co.edu.udistrital.model;

public class Computadora {
	
	//Declaración de los atributos
	private int procesador;
	private int ram;
	private int discoDuro;
	private int tarjetaGrafica;
	private String color; //Atributo de prueba
	
	//Constructor
	public Computadora(int procesador,int ram,int discoDuro,int tarjetaGrafica, String color){
		this.procesador = procesador;
		this.ram = ram;
		this.discoDuro = discoDuro;
		this.tarjetaGrafica = tarjetaGrafica;
		this.color=color;
	}
	
	
	//Getters y setters
	public int getProcesador() {
		return procesador;
	}

	public void setProcesador(int procesador) {
		this.procesador = procesador;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	public int getDiscoDuro() {
		return discoDuro;
	}

	public void setDiscoDuro(int discoDuro) {
		this.discoDuro = discoDuro;
	}

	public int getTarjetaGrafica() {
		return tarjetaGrafica;
	}

	public void setTarjetaGrafica(int tarjetaGrafica) {
		this.tarjetaGrafica = tarjetaGrafica;
	}
	
	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}
	
	
//Método para ver todas las propiedades 
	@Override
	public String toString() {
		return " Computadora: \n"+
				" Procesador = " + procesador + " nucleos \n"+
				" Ram = " + ram + " GB \n"+
				" Disco duro = " + discoDuro + " GB \n"+
				" Tarjeta Grafica = " + tarjetaGrafica + " GB \n" +
				" Color = " + color;
	}


	
	
	
	

}
