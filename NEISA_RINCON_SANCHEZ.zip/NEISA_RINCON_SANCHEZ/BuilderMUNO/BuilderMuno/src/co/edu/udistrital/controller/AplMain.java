package co.edu.udistrital.controller;

public class AplMain {
	
	public static void main(String[] ergs) {
		Controller control;
		control = new Controller();

	}

}
