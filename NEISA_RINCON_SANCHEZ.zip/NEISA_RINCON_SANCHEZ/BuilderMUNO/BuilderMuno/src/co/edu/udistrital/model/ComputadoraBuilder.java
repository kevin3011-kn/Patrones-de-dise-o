package co.edu.udistrital.model;

public class ComputadoraBuilder implements Builder {
	
	//Creación de la instancia Computadora
	private Computadora computadora;
	
	

	@Override
	public Builder reset() {
		this.computadora = new Computadora(0, 0, 0, 0,null);
		return null;
	}

	@Override
	public Builder setProcesador(int procesador) {
		this.computadora.setProcesador(procesador);
		//retorna la instancia de la clase
		return this;
	}



	@Override
	public Builder setRam(int ram) {
		this.computadora.setRam(ram);
		return this;
	}



	@Override
	public Builder setDiscoDuro(int discoDuro) {
		this.computadora.setDiscoDuro(discoDuro);
		return this;
	}



	@Override
	public Builder setTarjetaGrafica(int tarjetaGrafica) {
		this.computadora.setTarjetaGrafica(tarjetaGrafica);
		return this;
	}
	
	@Override
	public Builder setColor(String color) {
		this.computadora.setColor(color);
		return this;
	}
	
	
	@Override
	public Computadora build() {
		return this.computadora;
	}

	

	
	

}
