package co.edu.udistrital.model;

public class Director {
	public void createGamingComp(Builder builder,int proce,int ram,int discD,int tGrafica) {
		
		// En este caso la función del director se centra en especificar el orden de creación del computador Gaming
		builder.reset();
		builder.setProcesador(proce);
		builder.setRam(ram);
		builder.setDiscoDuro(discD);
		builder.setTarjetaGrafica( tGrafica);
		builder.setColor("Rosado");// Asignación de valor de la variable nueva de prueba
	}
	
	public void createOficinaComp(Builder builder,int ram,int discD,int proce) {
		
		// En este caso la función del director se centra en especificar el orden de creación del computador de oficina
		builder.reset();
		builder.setRam(ram);
		builder.setDiscoDuro(discD);
		builder.setProcesador(proce);
		

		
	}
	
	public void createPortatilComp(Builder builder,int proce,int ram,int tGrafica) {
		
		// En este caso la función del director se centra en especificar el orden de creación del computador portatil
		builder.reset();
		builder.setProcesador(proce);
		builder.setRam(ram);
		builder.setTarjetaGrafica(tGrafica);
	}
	
	

}
