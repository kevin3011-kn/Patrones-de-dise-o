package co.edu.udistrital.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import co.edu.udistrital.model.Builder;
import co.edu.udistrital.model.Computadora;
import co.edu.udistrital.model.ComputadoraBuilder;
import co.edu.udistrital.model.Director;
import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.view.VistaPrincipal;


public class Controller implements ActionListener{
	
	private VistaPrincipal vista;
	private Builder Builder;
	private Computadora Computadora;
	private Director Director;
	private ComputadoraBuilder CompuBuild;
	
	public Controller() {
		
		vista = new VistaPrincipal();
		asignarOyentes();
	}
	
public void asignarOyentes() {
    	
    	vista.getPp().getCrearButton().addActionListener(this);
    	vista.getPp().getTipoComputadoraCombo().addActionListener(this);
        
}


@Override
public void actionPerformed(ActionEvent e) {
	
	String comando = e.getActionCommand();
	
	 if(comando.equals("ACTUALIZAR")) {
		 
		
		 
		 String tipo = (String) vista.getPp().getTipoComputadoraCombo().getSelectedItem();

	        switch (tipo) {
	            case "Gaming":
	            	vista.getPp().getProcesadorField().setEnabled(true);
	            	vista.getPp().getRamField().setEnabled(true);
	            	vista.getPp().getDiscoDuroField().setEnabled(true);
	            	vista.getPp().getTarjetaGraficaField().setEnabled(true);
	                break;
	            case "Oficina":
	            	vista.getPp().getProcesadorField().setEnabled(true);
	            	vista.getPp().getRamField().setEnabled(true);
	            	vista.getPp().getDiscoDuroField().setEnabled(true);
	            	vista.getPp().getTarjetaGraficaField().setEnabled(true);
	            	vista.getPp().getTarjetaGraficaField().setText("");
	                break;
	            case "Portátil":
	            	vista.getPp().getProcesadorField().setEnabled(true);
	            	vista.getPp().getRamField().setEnabled(true);
	            	vista.getPp().getDiscoDuroField().setEnabled(true);
	            	vista.getPp().getDiscoDuroField().setText("");
	            	vista.getPp().getTarjetaGraficaField().setEnabled(true);
	                break;
	        }
	 }
	 
	 if(comando.equals("CREAR")) {
		 
		 String tipo = (String) vista.getPp().getTipoComputadoraCombo().getSelectedItem();

	        try {
	        	String textoProce = vista.getPp().getProcesadorField().getText().trim();
	            int proce = (vista.getPp().getProcesadorField().isEnabled() && !textoProce.isEmpty())
	            	    ? Integer.parseInt(textoProce)
	            	    	    : 0;
	            
	            String textoRam = vista.getPp().getRamField().getText().trim();
	            int ram = (vista.getPp().getRamField().isEnabled() && !textoRam.isEmpty())
	            	    ? Integer.parseInt(textoRam)
	            	    	    : 0;
	            
	            String textoDisco = vista.getPp().getDiscoDuroField().getText().trim();
	            int disco = (vista.getPp().getDiscoDuroField().isEnabled() && !textoDisco.isEmpty())
	            	    ? Integer.parseInt(textoDisco)
	            	    	    : 0;
	            
	            String textoTGrafica = vista.getPp().getTarjetaGraficaField().getText().trim();
	            int tGrafica = (vista.getPp().getTarjetaGraficaField().isEnabled() && !textoTGrafica.isEmpty())
	            	    ? Integer.parseInt(textoTGrafica)
	            	    	    : 0;
	            co.edu.udistrital.model.Builder builder = new co.edu.udistrital.model.ComputadoraBuilder();
	            co.edu.udistrital.model.Director director = new co.edu.udistrital.model.Director();

	            switch (tipo) {
	                case "Gaming":
	                    director.createGamingComp(builder, proce, ram, disco, tGrafica);
	                    break;
	                case "Oficina":
	                    director.createOficinaComp(builder, ram, disco, proce);
	                    break;
	                case "Portátil":
	                    director.createPortatilComp(builder, proce, ram, tGrafica);
	                    break;
	            }

	            co.edu.udistrital.model.Computadora computadora = builder.build();
	          
	            vista.getPp().getResultadoArea().setText(computadora.toString());

	        } catch (NumberFormatException ex) {
	            JOptionPane.showMessageDialog(null,
	                    "Por favor, ingrese números enteros válidos en los campos habilitados.",
	                    "Error de entrada",
	                    JOptionPane.ERROR_MESSAGE);
	        }
		 
		 
	 }
	 
 }
}

