package co.edu.udistrital.controller;

import co.edu.udistrital.model.EdificioUnico;
import co.edu.udistrital.view.VistaConsola;


public class Controller {

	private VistaConsola vista;
	
    public Controller() {
    	vista = new VistaConsola();
	}
    
    public void run() {
    	
    	EdificioUnico  obj= EdificioUnico.getinstancia();//creacio  de la instancia unica
        EdificioUnico otra = EdificioUnico.getinstancia();
        obj.setPruebaInstancia("UNIVERSIDAD DISTRITAL");
        vista.mostrarInformacion(otra.getPruebaInstancia());
       
        //EdificioUnico nueva = new EdificioUnico(); // creacion normal de un objeto
            
            
    }
        
}
